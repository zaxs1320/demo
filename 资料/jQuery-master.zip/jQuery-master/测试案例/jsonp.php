<?php
    header('Content-Type:text/json;charset=utf-8');
 //	echo trim( $_GET['callback']).'('. json_encode(array('status'=>1,'info'=>'OK')) .')';
 	echo json_encode(array('status'=>1,'info'=>'OK'));  
?>