module.exports = {
    plugins: {
        'autoprefixer': {},
    }
}