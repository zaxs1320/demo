# flower
The flowers which are growing in canvas...

The path formula of love comes from the network.
爱心的路径公式来源于网络 >>    [公式](http://www.wolframalpha.com/input/?i=x+%3D+16+sin%5E3+t,+y+%3D+(13+cos+t+-+5+cos+2t+-+2+cos+3t+-+cos+4t))

Sorry for my Math...  0.0

## Ver. jQuery  
旧版本，用的jquery，但是在06年某次chrome更新之后，，，竟然有卡顿现象，其它浏览器都正常啊有木有？？！！

## Ver. TypeScript with myself task lib ~  (用我自己写的异步库，结合typescript来做，diao,diao,diao~)
新版本，用的typescript重写，然后异步库是自己写的，支持 node,amd,browser => [simple-task](https://github.com/shalldie/simple-task)

It looks like 

![image](https://github.com/shalldie/flower/raw/master/img/GIF.gif)
