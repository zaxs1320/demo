# qin
琴弦文字，基于jquery的琴弦文字效果插件。

[点击查看demo](https://shalldie.github.io/demos/qin/index.html)

![qin](https://raw.githubusercontent.com/shalldie/qin/master/qin.gif)